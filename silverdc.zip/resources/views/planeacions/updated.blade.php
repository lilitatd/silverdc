@extends('layouts.app')

@section('title', ' - Planeaciones')

@section('content')
<div class="text-center">
	<div class="alert alert-info">
		La planeación fue actualizada...
	</div>
</div>
@endsection