<?php $__env->startSection('title', ' - Planeaciones'); ?>

<?php $__env->startSection('content'); ?>
	<?php echo Form::model($planeacion, ['route' => ['planeaciones.update', $planeacion], 'method' => 'PUT']); ?>

	<div class="form-group">
			<?php echo Form::label('nombre', 'Nombre'); ?>

			<?php echo Form::text('nombre', null, ['class' => 'form-control', 'maxlength' => 20]); ?>

			<?php echo Form::label('fecha', 'Fecha'); ?>

			<?php echo Form::date('fecha'); ?>

			<?php echo Form::label('avanceTotal', 'Avance total'); ?>

			<?php echo Form::text('avanceTotal', null, ['class' => 'form-control']); ?>

			<?php echo Form::label('avancePorDia', 'Avance por día'); ?>

			<?php echo Form::text('avancePorDia', null, ['class' => 'form-control']); ?>

			<?php echo Form::label('diasTrabajo', 'Días de trabajo'); ?>

			<?php echo Form::text('diasTrabajo', null, ['class' => 'form-control']); ?>

			<?php echo Form::label('gestion', 'Gestión'); ?>

			<?php echo Form::selectRange('gestion', 2018, 2030); ?>

			<?php echo Form::label('mes', 'Mes'); ?>

			<?php echo Form::select('mes', ['Enero' => 'Enero', 'Febrero' => 'Febrero', 'Marzo' => 'Marzo', 'Abril' => 'Abril', 'Mayo' => 'Mayo', 'Junio' => 'Junio', 'Julio' => 'Julio', 'Agosto' => 'Agosto', 'Septiembre' => 'Septiembre', 'Octubre' => 'Octubre', 'Noviembre' => 'Noviembre', 'Diciembre' => 'Diciembre']); ?>

			<?php echo Form::label('est', 'Est'); ?>

			<?php echo Form::text('est', null, ['class' => 'form-control']); ?>

		</div>
		<?php echo Form::submit('Actualizar', ['class' => 'btn btn-primary']); ?>

	<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>