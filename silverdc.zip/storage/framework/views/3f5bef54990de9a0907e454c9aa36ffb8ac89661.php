<?php $__env->startSection('title', ' - Planeaciones'); ?>

<?php $__env->startSection('content'); ?>
	<?php if($errors->any()): ?>
		<div class="alert alert-danger">
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>				
			</ul>
		</div>
	<?php endif; ?>
	<?php echo Form::open(['route' => 'planeacions.store', 'method' => 'POST']); ?>

		<div class="form-group">
			<?php echo Form::label('nombre', 'Nombre'); ?>

			<?php echo Form::text('nombre', null, ['class' => 'form-control']); ?>

			<?php echo Form::label('fecha', 'Fecha'); ?>

			<?php echo Form::date('fecha', \Carbon\Carbon::now()); ?>

			<?php echo Form::label('avanceTotal', 'Avance total'); ?>

			<?php echo Form::text('avanceTotal', null, ['class' => 'form-control']); ?>

			<?php echo Form::label('avancePorDia', 'Avance por día'); ?>

			<?php echo Form::text('avancePorDia', null, ['class' => 'form-control']); ?>

			<?php echo Form::label('diasTrabajo', 'Días de trabajo'); ?>

			<?php echo Form::text('diasTrabajo', null, ['class' => 'form-control']); ?>

			<?php echo Form::label('gestion', 'Gestión'); ?>

			<?php echo Form::selectRange('gestion', 2018, 2030); ?>

			<?php echo Form::label('mes', 'Mes'); ?>

			<?php echo Form::select('mes', ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']); ?>

			<?php echo Form::label('est', 'Est'); ?>

			<?php echo Form::text('est', null, ['class' => 'form-control']); ?>

		</div>
		<?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

	<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>