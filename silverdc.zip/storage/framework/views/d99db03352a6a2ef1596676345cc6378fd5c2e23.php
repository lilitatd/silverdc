<?php $__env->startSection('title', ' - Lista de planeaciones'); ?>

<?php $__env->startSection('content'); ?>
	<div class="text-center"><h1>LISTA DE PLANEACIONES</h1></div>
	<div class="text-right"><a href="/planeacions/create" class="w3-button w3-circle" style="background-color:#dbe8ff">+</a></div>
	<table class="table table-bordered">
		<thead>
			<tr>
				<td>Nombre</td>
				<td>Fecha</td>
				<td>Avance total</td>
				<td>Avance día</td>
				<td>Gestión</td>
				<td>Mes</td>
				<td>Acción</td>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $planeaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $planeacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($planeacion->nombre); ?></td>
				<td><?php echo e($planeacion->fecha); ?></td>
				<td><?php echo e($planeacion->avanceTotal); ?></td>
				<td><?php echo e($planeacion->avancePorDia); ?></td>
				<td><?php echo e($planeacion->gestion); ?></td>
				<td><?php echo e($planeacion->mes); ?></td>
				<td><a href="/planeacions/<?php echo e($planeacion->id); ?>" class="btn btn-primary">Ver más...</a>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>