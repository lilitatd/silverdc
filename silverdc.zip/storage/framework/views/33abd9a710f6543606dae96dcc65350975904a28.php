<?php $__env->startSection('title', '- Planeación'); ?>

<?php $__env->startSection('content'); ?>
	<table class="table table-bordered">
		<tbody>
			<tr>
				<th>Nombre</th>
				<td><?php echo e($planeacion->nombre); ?></td>
			</tr>
			<tr>
				<th>Fecha</th>
				<td><?php echo e($planeacion->fecha); ?></td>				
			</tr>
			<tr>
				<th>Avance total</th>
				<td><?php echo e($planeacion->avanceTotal); ?></td>
			</tr>
			<tr>
				<th>Avance día</th>
				<td><?php echo e($planeacion->avancePorDia); ?></td>
			</tr>
			<tr>
				<th>Gestión</th>
				<td><?php echo e($planeacion->gestion); ?></td>
			</tr>
			<tr>
				<th>Mes</th>
				<td><?php echo e($planeacion->mes); ?></td>
			</tr>
		</tbody>
	</table>
	<div class="text-center">
		<a href="/planeacions/<?php echo e($planeacion->id); ?>/edit" class="btn btn-primary">Editar</a>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>