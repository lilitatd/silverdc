<p align="center"><img src="https://laravel.com/assets/img/components/logo-laravel.svg"></p>

<p align="center">
<a href="https://travis-ci.org/laravel/framework"><img src="https://travis-ci.org/laravel/framework.svg" alt="Build Status"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://poser.pugx.org/laravel/framework/d/total.svg" alt="Total Downloads"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://poser.pugx.org/laravel/framework/v/stable.svg" alt="Latest Stable Version"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://poser.pugx.org/laravel/framework/license.svg" alt="License"></a>
</p>

## Acerca de: SILVER DC

Silver DC, es una aplicación web que permite realizar el cálculo del número de taladros para diferentes tipos de labores, entre las principales funciones que posee estan:

- Creación de planeaciones de explotacion.
- Cálculo del nro de taladros y algunos materiales en función a una sección y una labor dada.
- Creación y asignacion de boletas según los valores hallados en el punto anterior.